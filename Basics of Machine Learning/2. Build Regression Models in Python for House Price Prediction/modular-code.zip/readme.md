## 1. Create a new environment

## 2. Install all the requirements
Tested on 3.8.10
pip install -r requirements.txt

## 3. Run the engine.py file to execute the code

python engine.py
